package com.example.vyanezgx.menu1;

import android.app.LauncherActivity;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
//agrego este texto
    private TextView txtHelloWorld;
    private ListView listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//agrego este texto
    txtHelloWorld= (TextView)findViewById(R.id.txtHelloWorld);
    listItems= (ListView)findViewById(R.id.listItems);

    String [] datos ={"item 1","item 2","item 3","item 4","item 5","item 6"};
    ArrayAdapter<String> adp= new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, datos);

    listItems.setAdapter(adp);
    ///registrar los controles para menus contextuales
    registerForContextMenu(txtHelloWorld);
    registerForContextMenu(listItems);
    }
//agrego  estos metodos con "ctrl, + ,O"
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
//agregar lo siguiente identificar sobre que control hicimos el toque largo
    int id=v.getId();
        MenuInflater inflater=getMenuInflater();
       switch (id) {
           case R.id.txtHelloWorld:
               inflater.inflate(R.menu.menu_main_textview, menu);
               break;
           case R.id.listItems:
               inflater.inflate(R.menu.menu_main_listview, menu);
               break;
       }

    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        return super.onContextItemSelected(item);
    }
}
