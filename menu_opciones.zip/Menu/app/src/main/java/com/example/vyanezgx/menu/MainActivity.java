package com.example.vyanezgx.menu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

     /* ahora crearemos la funcion menu para poder utilizar nuestro
     Menú de opciones
    en ocasiones nos marca error la libreria MEnu la cual hay que importarla con alt+enter
    */
    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        //This class (MenuInflater()) is used to instantiate menu
        // XML files into Menu objects
        // inflate the menu, this adds items to the action bar if it is presents
    getMenuInflater().inflate(R.menu.menu_main, menu);
     return true;
    }


    /* ahora crearemos la funcion  onOptionsItemSelected
    la cual le diremos que hacer en el menu de opciones
    dependiendo de que item le hagamos el clic
    esto por medio de un clic
   */

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
    int id= item.getItemId();
    switch (id) {
        case R.id.menu_opcion1:
            Toast.makeText(
                    MainActivity.this
                    , "presionaste la opcion 1",
                    Toast.LENGTH_SHORT).show();
            return true;
        case R.id.menu_opcion2:
            Toast.makeText(
                    MainActivity.this
                    , "presionaste la opcion 2",
                    Toast.LENGTH_SHORT).show();
            return true;
        case R.id.menu_salir:
            Toast.makeText(
                    MainActivity.this
                    , "presionaste salir",
                    Toast.LENGTH_SHORT).show();
            finish();
        default:
            return super.onOptionsItemSelected(item);
        }
      /*  if(id = R.id.action_settings){
            return true;
        }*/

    }
}
